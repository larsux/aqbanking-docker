#include <ktoblzcheck.h>

int main()
{
    AccountNumberCheck checker;
    return checker.bankCount();
}
